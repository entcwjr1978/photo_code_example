package com.lightcyclesoftware.photoscodeexample.application

import android.app.Application

/**
 * Created by Edward on 2/4/2018.
 */

class PhotoApplication: Application() {
    override fun onCreate() {
        super.onCreate()
    }
}