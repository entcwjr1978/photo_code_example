package com.lightcyclesoftware.photoscodeexample.event

/**
 * Copyright (c) 2017 ADP. All rights reserved.
 */

data class Event(var name: String, var data: MutableMap<String, Any?>)