package com.lightcyclesoftware.photoscodeexample.model

/**
 * Created by Edward on 2/4/2018.
 */
data class Data (var album: Album)