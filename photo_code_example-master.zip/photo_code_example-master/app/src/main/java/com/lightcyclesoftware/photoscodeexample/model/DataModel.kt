package com.lightcyclesoftware.photoscodeexample.model

/**
 * Created by Edward on 2/3/2018.
 */

data class DataModel(var data: Data)