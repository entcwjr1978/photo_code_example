package com.lightcyclesoftware.photoscodeexample.model

/**
 * Created by Edward on 2/4/2018.
 */
data class Photos( var records: List<Record>)