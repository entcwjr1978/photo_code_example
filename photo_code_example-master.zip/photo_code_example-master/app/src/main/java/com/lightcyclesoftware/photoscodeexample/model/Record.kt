package com.lightcyclesoftware.photoscodeexample.model

/**
 * Created by Edward on 2/4/2018.
 */

data class Record(var id: String, var urls: List<Url>)