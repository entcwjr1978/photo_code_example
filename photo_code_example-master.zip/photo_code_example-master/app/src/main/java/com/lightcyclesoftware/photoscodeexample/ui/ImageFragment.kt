package com.lightcyclesoftware.photoscodeexample.ui

import android.os.Build
import android.os.Bundle
import android.support.v4.app.Fragment
import android.transition.TransitionInflater
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.lightcyclesoftware.photoscodeexample.R
import android.graphics.Bitmap
import android.graphics.Color
import android.support.constraint.ConstraintLayout
import android.support.v7.graphics.Palette
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition


/**
 * Copyright (c) 2017 ADP. All rights reserved.
 */
class ImageFragment: Fragment() {
    var url: String? = null
    var clickedItem: String? = null
    var image: ImageView? = null
    var topLayout: ConstraintLayout? = null
    companion object {
        fun newInstance(url: String?, clickedItem: String?): ImageFragment {
            var imageFragment = ImageFragment()
            var bundle = Bundle()
            bundle.putString("URL", url)
            bundle.putString("CLICKED_ITEM", clickedItem)
            imageFragment.arguments = bundle
            return imageFragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        url = arguments?.getString("URL")
        clickedItem = arguments?.getString("CLICKED_ITEM")
        //postponeEnterTransition()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.image_viewer_layout, container, false)
        image = view.findViewById(R.id.image)
        image?.transitionName = clickedItem
        topLayout = view.findViewById(R.id.top_view)
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Glide.with(this)
                .asBitmap()
                .load(url)
                .into(target)

    }

    private val target = object : SimpleTarget<Bitmap>() {
        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
            image?.setImageBitmap(resource)
            createPaletteAsync(resource)
        }
    }

    fun createPaletteAsync(bitmap: Bitmap) {
        Palette.from(bitmap).generate { palette ->
            topLayout?.setBackgroundColor(palette.getDarkMutedColor(Color.DKGRAY))
        }
    }
}